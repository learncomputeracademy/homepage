// newtab.js
window.location.replace("https://homepage.computercenter.in/");