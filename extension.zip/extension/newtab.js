document.addEventListener("DOMContentLoaded", function() {
  window.location.href = "https://homepage.computercenter.in/";
});